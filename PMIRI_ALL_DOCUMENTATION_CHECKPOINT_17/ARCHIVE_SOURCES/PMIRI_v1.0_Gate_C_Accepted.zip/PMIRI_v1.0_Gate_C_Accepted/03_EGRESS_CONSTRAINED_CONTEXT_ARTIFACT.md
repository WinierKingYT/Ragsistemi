# PMIRI — Egress-Constrained Context Artifact

**Version:** 1.0  
**Status:** GATE C FINAL ACCEPTED

## Type separation

`CompiledContextArtifact` remains provider-neutral.

A Gate-D provider/model/feature-specific constraint set MUST NOT mutate it or produce another object falsely presented as provider-neutral.

Use:

```text
EgressConstrainedContextArtifact
- constrained_context_artifact_id
- source_compiled_context_artifact_id
- source_evidence_set_id
- source_context_intent_id
- exact destination binding ref
- Gate-D egress constraint set ref
- allowed EvidenceItem/view refs
- excluded-by-egress refs (internal only)
- inherited_epistemic_ceiling_ref
- semantic_obligation_set_ref
- constraint_disposition
- segment revision refs
- constrained citation map ref
- transform/fidelity refs
- omission ledger ref
- trust/content-class refs
- input cut/epoch coverage
- authorization_lineage_ref
- validity/freshness metadata
- created_at
```

## Constraint disposition

```text
PRESERVES_ORIGINAL_OBLIGATIONS
DEGRADED_BUT_EXPLICITLY_ALLOWED_BY_INTENT
UNSATISFIABLE_FOR_DESTINATION
INDETERMINATE
```

No constraint may silently weaken a hard `SemanticObligationSet`.

## No evidence resurrection

The constrained compiler may only select/transform from material already present in the admitted source EvidenceSet and allowed by Gate-D constraints.

It MUST NOT:
- retrieve new evidence implicitly;
- re-add previously omitted/denied evidence;
- turn navigation-only material into evidence;
- bypass lifecycle/standing/access restrictions.

If new evidence is needed, the system starts a new authorized retrieval request with an appropriately narrowed hard envelope.

## Validity

`ContextEmissionValidityDecision` is generalized downstream to cover either:
- provider-neutral `CompiledContextArtifact`, or
- `EgressConstrainedContextArtifact`.

The constrained artifact also binds exact destination/egress-policy validity before ProviderEnvelope assembly.
