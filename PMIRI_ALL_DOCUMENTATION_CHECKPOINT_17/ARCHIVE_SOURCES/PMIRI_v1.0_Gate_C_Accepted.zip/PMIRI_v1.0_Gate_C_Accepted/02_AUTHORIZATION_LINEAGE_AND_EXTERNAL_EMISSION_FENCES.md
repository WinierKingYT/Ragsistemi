# PMIRI — Authorization Lineage and External Emission Fences

**Version:** 1.0  
**Status:** GATE C FINAL ACCEPTED / SAFETY-CRITICAL

## AuthorizationLineageRef

A non-secret derived reference binds an artifact to the trusted request authorization basis that produced it.

```text
AuthorizationLineageRef
- lineage_id
- request_authorization_binding_ref
- principal/trust-zone binding fingerprint
- allowed-domain basis fingerprint
- Gate-D policy-input/version refs
- originating operation/request id
- created_at
```

It MUST be propagated, directly or through immutable parent references, through any derived artifact that can reach an external boundary.

`AuthorizationLineageRef` is audit/freshness lineage, not a bearer token.

## R1 compatibility

The historical Gate-C R1 `authorization_context_ref` field is interpreted under current authority only as a reference to a trusted server-derived authorization context/binding. Untrusted callers MUST NOT select or supply a privileged value.

## AuthorizationValidityDecision

Immediately before external output, current Gate-D-owned authorization/disclosure policy evaluates whether the relevant authorization lineage remains valid for the requested external boundary.

Possible abstract outcomes:

```text
VALID
REPROJECT_REQUIRED
REAUTHORIZE_REQUIRED
DENIED
INDETERMINATE
```

## ExternalReadEmissionFence

Every evidence-bearing API/MCP response MUST pass a last-local-boundary fence:

```text
ExternalReadEmissionFence
- operation/request id
- external typed result fingerprint
- AuthorizationLineageRef
- AuthorizationValidityDecision ref
- Gate-D disclosure-projection ref + validity
- required EvidenceRestrictionEpoch coverage
- required SemanticResolutionEpoch coverage?
- current lifecycle/standing coverage refs
- continuation integrity ref?
- checked_at
- result:
    EMIT_VALID
    REPROJECT_REQUIRED
    REVALIDATE_REQUIRED
    DENIED
    INDETERMINATE
```

This fence is the direct-read analogue of `ProviderSendFence`.

A restriction/access/policy/semantic change after retrieval but before caller response cannot be ignored merely because the internal result was previously valid.
