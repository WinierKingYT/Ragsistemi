# PMIRI — External Read Projection and API/MCP Parity

**Version:** 1.0  
**Status:** GATE C FINAL ACCEPTED

## Universal external read boundary

Every V1 external read operation follows:

```text
InternalSemanticResult
  -> Gate-D ExternalReadDisclosureProjection
  -> ExternalTypedResult
  -> ExternalReadEmissionFence
  -> caller
```

Applies to:

```text
search
fetch_evidence
resolve_current_state
retrieve_history
timeline
explain
status
```

No operation is exempt merely because it is read-only.

## ExternalReadDisclosureProjection

Gate D owns the policy logic. Gate C requires the projection interface to be able to remove/coarsen existence-sensitive information without changing the internal semantic result.

Internal-only information may include:
- inaccessible-existence distinction;
- denied-match counts;
- hidden candidate IDs;
- restricted-source reason codes;
- internal omission ledger entries;
- policy/debug diagnostics;
- protected project/connector enumeration.

The external typed result MUST preserve the epistemic state it is allowed to disclose without inventing a stronger state.

## MCP/API semantic parity

MCP and protocol-neutral API adapters MUST implement the same semantic operations and trusted per-request authorization model.

MCP-specific:
- `readOnlyHint` is descriptive only;
- safety-critical output uses validated structured content;
- stateless requests cannot depend on hidden connection-local correctness state;
- resource URIs/cursors/handles are locators only.

Transport-neutral:
- RequestAuthorizationBinding comes from the trusted boundary;
- continuations bind original constraints and integrity proof;
- current access is re-evaluated;
- protocol errors remain distinct from typed domain outcomes.
