# PMIRI — Gate C Final Accepted Decision Register

**Version:** 1.0  
**Status:** GATE C ACCEPTED

| ID | Final accepted decision |
|---|---|
| GC-F01 | R1/R2/R3 accepted semantics remain in force except where this final compatibility package explicitly narrows/generalizes them. |
| GC-F02 | Authorization is server-derived per request and authorization lineage must remain traceable through derived artifacts that reach external boundaries. |
| GC-F03 | Historical R1 `authorization_context_ref` cannot be client-selected authority; it refers only to trusted internal authorization context. |
| GC-F04 | Every evidence-bearing direct API/MCP response uses Gate-D disclosure projection plus `ExternalReadEmissionFence`. |
| GC-F05 | ProviderSendFence remains the final provider-transport boundary; direct-read fence is separate. |
| GC-F06 | `CompiledContextArtifact` remains provider-neutral. |
| GC-F07 | Provider-specific constrained compilation produces `EgressConstrainedContextArtifact`, never an in-place/provider-specific `CompiledContextArtifact`. |
| GC-F08 | Constrained compilation cannot add/retrieve/revive evidence and cannot silently weaken hard semantic obligations. |
| GC-F09 | Retrieval coverage, evidence sufficiency, candidate-universe completeness and answerability cannot be strengthened by compiler/envelope/projection layers. |
| GC-F10 | Unresolved conflict must survive or cause explicit degraded/unsatisfiable/deny outcome. |
| GC-F11 | Citation lineage survives canonical anchor → EvidenceItem → compiled span → constrained span → provider alias. |
| GC-F12 | Evidence-data/control classification survives transforms/wrappers; source text never becomes policy/control authority. |
| GC-F13 | Destination fit, Gate-D authorization, authorization validity and payload/profile binding are distinct required proofs. |
| GC-F14 | Continuations are integrity-protected state carriers/handles, never authorization. |
| GC-F15 | All external read operations, including search/fetch/current-state/history/timeline, use disclosure-safe projection; explain/status are not special exceptions. |
| GC-F16 | MCP and protocol-neutral API share the same semantic operation contracts and trusted per-request authorization model. |
| GC-F17 | V1 remains semantically read-only. |
| GC-F18 | Gate C is closed; Gate D owns security/disclosure policy and Gate E owns quantitative quality/performance acceptance. |
