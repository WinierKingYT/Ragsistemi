# PMIRI — Gate C Final Cross-Round Compatibility Contract

**Version:** 1.0  
**Status:** GATE C FINAL ACCEPTED

## End-to-end chain

```text
Trusted Request Boundary
  -> RequestAuthorizationBinding
  -> SearchRequest / ConstraintEnvelope
  -> RetrievalReadView / Coverage / Admission
  -> EvidenceSet / ResolutionCandidateUniverse
  -> ContextIntent / SemanticObligationSet
  -> CompiledContextArtifact            # provider-neutral
  -> [optional] EgressConstrainedContextArtifact
  -> EgressHandoffRequest
  -> Gate-D EgressDecision
  -> DestinationFit / ProviderEnvelope
  -> ProviderSendFence
  -> provider transport

or

InternalSemanticResult
  -> Gate-D ExternalReadDisclosureProjection
  -> ExternalReadEmissionFence
  -> API/MCP caller
```

## Cross-round invariants

1. Relevance/rank/packing/formatting never create truth, authority, standing, authorization or current-state precedence.
2. No later layer may strengthen retrieval coverage, evidence sufficiency, candidate-universe completeness or answerability beyond inherited ceilings.
3. No reference, cursor, URI, artifact ID or prior result is authorization.
4. Authorization is server-derived per request and its lineage/freshness must remain checkable at each external boundary.
5. Provider-specific constraints never mutate provider-neutral artifacts in place.
6. External disclosure projection is mandatory for every read operation, not only explain/status.
7. Historical semantics never bypass current access/restriction emission safety.
8. Citation lineage and evidence-data/control-class lineage survive all accepted transforms.
9. External output is blocked or revalidated if current restriction, semantic, authorization or disclosure state changes beyond proven coverage.
