# PMIRI — Gate C Final Recheck Plan

Re-run these end-to-end checks after the patch:

R-FC-01 query rewrite + later fetch cannot widen/access by reference.
R-FC-02 stale/mixed retrieval cannot become complete context.
R-FC-03 partial/unknown current-state universe cannot become complete current state.
R-FC-04 correction/retraction/restriction at every stage is caught by the applicable fence.
R-FC-05 unresolved conflict survives or route becomes explicitly unsatisfiable/deny.
R-FC-06 citation identity survives retrieval → EvidenceSet → compiled span → constrained span → provider alias.
R-FC-07 fit/recompile cannot revive omitted/restricted evidence.
R-FC-08 destination/profile/payload proof substitution fails.
R-FC-09 historical semantics retain recorded-time view and current access safety.
R-FC-10 continuation cannot widen/tamper and never authorizes.
R-FC-11 every external read operation uses Gate-D disclosure-safe projection.
R-FC-12 MCP/API use the same trusted per-request authorization semantics.
R-FC-13 safety-critical structured MCP result matches transport-neutral typed state.
R-FC-14 read-only operations cannot mutate canonical/user-domain semantic state.
R-FC-15 authorization revocation after retrieval but before direct API response blocks/reprojects output.
R-FC-16 provider-specific constrained recompile cannot masquerade as provider-neutral compiled context.
R-FC-17 evidence-data/control classification survives all transforms/wrappers.
