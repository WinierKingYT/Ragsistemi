# PMIRI — Gate C Final Required Patch Set

## P-CF-01 — AuthorizationLineageRef
Every derived artifact that can cross an external boundary MUST retain a non-secret reference/fingerprint to the trusted server-derived `RequestAuthorizationBinding` lineage:
SearchRequest/ConstraintEnvelope → RetrievalRun/EvidenceSet → ContextIntent/CompiledContextArtifact → EgressHandoff/ProviderEnvelope or external read projection.

The lineage reference is not itself an authorization token.

## P-CF-02 — AuthorizationValidityDecision
Before external emission, current authorization validity must be re-established under Gate-D-owned policy semantics. Access revocation/policy change after retrieval cannot be hidden by stale artifacts.

## P-CF-03 — ExternalReadEmissionFence
Every evidence-bearing API/MCP response uses a last-local-boundary fence covering:
- trusted request authorization validity;
- Gate-D disclosure projection validity;
- evidence restriction epoch;
- semantic resolution epoch when relevant;
- current access/lifecycle/standing;
- typed result/projection fingerprint.

## P-CF-04 — EgressConstrainedContextArtifact
Provider-specific constrained recompilation MUST NOT produce or mutate a provider-neutral `CompiledContextArtifact`.
Create a distinct destination-constrained derived artifact with:
- source compiled artifact/evidence set refs;
- exact Gate-D constraint set;
- exact destination binding;
- allowed evidence subset/view;
- inherited epistemic ceiling;
- semantic obligation disposition;
- regenerated citation/transform/omission lineage;
- its own emission-validity state.

It may narrow; it cannot add/retrieve/revive evidence.

## P-CF-05 — ExternalReadDisclosureProjection
Every external read operation follows:
`InternalSemanticResult -> Gate-D DisclosureProjection -> ExternalTypedResult`.
Internal omission reasons, denied-match counts, protected existence, internal candidate IDs and policy diagnostics are not externally mandatory.

## P-CF-06 — R1 authorization-context compatibility
The historical R1 `authorization_context_ref` is narrowed for current authority:
it refers only to a trusted server-derived authorization binding/context. An untrusted caller cannot supply/select it to grant access.

## P-CF-07 — Data/control-class preservation
Trust/content class from R2 must survive constrained compilation and ProviderEnvelope assembly. Retrieved evidence text cannot become trusted control through wrapper transformation.
