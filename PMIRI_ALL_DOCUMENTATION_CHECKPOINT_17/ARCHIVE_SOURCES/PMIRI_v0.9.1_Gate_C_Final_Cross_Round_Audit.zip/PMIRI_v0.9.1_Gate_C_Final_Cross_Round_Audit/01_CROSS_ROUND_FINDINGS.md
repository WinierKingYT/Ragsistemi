# PMIRI — Gate C Final Cross-Round Findings

## FC-01 — Constraint rewrite + reference reuse
PASS with amendment. R1 prevents query widening and R3 prevents refs from acting as capabilities. Final contract must bind both to the same trusted request authorization lineage.

## FC-02 — Stale/mixed retrieval → context completeness
PASS. R1 coverage degradation is inherited by R2 `InheritedEpistemicCeiling`; compiler packing cannot upgrade evidence-universe completeness.

## FC-03 — Partial current-state universe → false complete state
PASS. `ResolutionCandidateUniverse` coverage is inherited into context and cannot be strengthened by envelope formatting.

## FC-04 — Retrieval/compile/handoff/send semantic race
PARTIAL / BLOCKER. ProviderSendFence closes provider send, but direct external read responses need an equivalent last local response fence.

## FC-05 — Unresolved conflict through ranking/budget/egress
PASS subject to constrained-artifact type patch. Conflict obligations are hard; if Gate-D constraints remove a side, route is constrained recompile/degrade/deny.

## FC-06 — Citation identity end-to-end
PASS. Stable canonical anchor → EvidenceItem → CompiledSpanRef → final provider-visible span/citation projection remains traceable.

## FC-07 — Fit/recompile cannot revive evidence
PASS subject to constrained-artifact type patch. Recompile may only operate over an explicitly constrained view of already admitted evidence and MUST NOT retrieve/revive evidence silently.

## FC-08 — Destination proof substitution
PASS. Exact destination/payload/profile fingerprints prevent reuse across provider/model/feature.

## FC-09 — Historical semantics + current access safety
PASS. Historical recorded-time semantics do not bypass current access/restriction emission safety.

## FC-10 — Continuation widening/tamper
PASS. Bound continuation descriptor + integrity proof + current access recheck.

## FC-11 — Explain/status leak
PASS locally, but revealed a broader blocker: the same Gate-D disclosure projection rule must apply to all external read operations, not only explain/status.

## FC-12 — MCP stateless vs protocol-neutral API parity
PARTIAL / BLOCKER. Semantic operation parity is sound, but trusted authorization binding must be propagated identically through both adapters and the downstream artifact chain.

## FC-13 — Structured MCP vs typed API result
PASS. Safety-critical MCP output is schema-validated structured state; prose is presentation only.

## FC-14 — Read-only hidden semantic mutation
PASS. Canonical/user-domain semantic mutation remains forbidden; operational logs/caches cannot grant authority or alter canonical semantics.
